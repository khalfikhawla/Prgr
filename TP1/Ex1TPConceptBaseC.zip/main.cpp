#include <iostream>
using namespace std;

int main(){
	int Variable = 5; 
	cout << "Variable : " << Variable << endl;
	int *pVar = &Variable;
	*pVar = 9; 
	cout <<"Variable : " <<*pVar << endl;
	return 0; 
}
