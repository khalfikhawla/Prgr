#include <iostream>
using namespace std;

int main(){

  int var1, var2;
  int *Pvar1 = &var1;
  int *Pvar2 = &var2;
  void ex3(int  *Pvar1, int *Pvar2){
    *Pvar1 = 5;
    *Pvar2 = 6;
  }

  ex3(int *Pvar1, int *Pvar2);
	return 0; 
}
