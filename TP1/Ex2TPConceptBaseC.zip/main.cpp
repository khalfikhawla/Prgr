#include <iostream>
using namespace std;
int main(){
	// int Variable = 5; 
	// cout << "Variable : " << Variable << endl;
	// int *pVar = &Variable;
	// *pVar = 9; 
	// cout <<"Variable : " <<*pVar << endl;
  const int  Var1 = 0;
  const int* PVar1 = &Var1;
  Var1 = 6;
  *PVar1 = 7;
  //----
  int  var2 = 6; 
  int* Pvar2 = &var2;
  *Pvar2 = 7;




	return 0; 
}
